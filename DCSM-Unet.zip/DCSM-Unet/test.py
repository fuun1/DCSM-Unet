import os
import torch
import logging
from tqdm import tqdm
import numpy as np
from datetime import datetime

from model import DCSMUnet
from utils import Config, calculate_metrics
from utils.visualizer import visualize_prediction, save_prediction

def setup_logging(config):
    """设置日志"""
    log_dir = os.path.join(config.log_dir, 'test', datetime.now().strftime('%Y%m%d_%H%M%S'))
    os.makedirs(log_dir, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(log_dir, 'test.log')),
            logging.StreamHandler()
        ]
    )
    return log_dir

def test(model, test_loader, device, save_dir):
    """测试模型"""
    model.eval()
    metrics_sum = {'iou': 0, 'dice': 0, 'precision': 0, 'recall': 0, 'f1': 0, 'hd95': 0}
    
    with torch.no_grad():
        for batch_idx, (data, target) in enumerate(tqdm(test_loader, desc='Testing')):
            data, target = data.to(device), target.to(device)
            pred = model(data)
            
            # 计算评估指标
            metrics = calculate_metrics(pred, target)
            for k, v in metrics.items():
                metrics_sum[k] += v
            
            # 保存预测结果
            for i in range(len(data)):
                # 保存可视化结果
                vis_path = os.path.join(save_dir, f'vis_sample_{batch_idx}_{i}.png')
                visualize_prediction(data[i], pred[i], target[i], vis_path)
                
                # 保存预测掩码
                mask_path = os.path.join(save_dir, f'mask_sample_{batch_idx}_{i}.png')
                save_prediction(pred[i], mask_path)
    
    # 计算平均指标
    avg_metrics = {k: v / len(test_loader) for k, v in metrics_sum.items()}
    
    return avg_metrics

def main():
    # 加载配置
    config = Config()
    
    # 设置随机种子
    torch.manual_seed(config.seed)
    np.random.seed(config.seed)
    
    # 设置设备
    device = torch.device(config.device if torch.cuda.is_available() else "cpu")
    
    # 设置日志和保存目录
    log_dir = setup_logging(config)
    save_dir = os.path.join(log_dir, 'predictions')
    os.makedirs(save_dir, exist_ok=True)
    
    logging.info(f"Testing on device: {device}")
    
    # 创建模型
    model = DCSMUnet(
        in_channels=config.in_channels,
        out_channels=config.out_channels,
        base_channels=config.base_channels
    ).to(device)
    
    # 加载模型权重
    checkpoint = torch.load(os.path.join(config.save_dir, 'best_model.pth'), map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    logging.info(f"Loaded checkpoint from epoch {checkpoint['epoch']}")
    
    # 加载测试数据集
    # TODO: 实现测试数据集加载
    test_loader = None
    
    # 测试模型
    metrics = test(model, test_loader, device, save_dir)
    
    # 记录测试结果
    logging.info("Test Results:")
    for metric_name, value in metrics.items():
        logging.info(f"{metric_name}: {value:.4f}")
    
    # 保存测试结果到文件
    with open(os.path.join(log_dir, 'test_results.txt'), 'w') as f:
        for metric_name, value in metrics.items():
            f.write(f"{metric_name}: {value:.4f}\n")

if __name__ == '__main__':
    main() 