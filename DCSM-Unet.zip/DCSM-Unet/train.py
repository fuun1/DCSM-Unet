import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import numpy as np
from datetime import datetime

from model.dcsm_unet import DCSMUnet
from utils.dataset import YourDataset  # 需要根据实际数据集修改
from utils.losses import DiceLoss, FocalLoss
from utils.metrics import calculate_metrics
from utils.logger import setup_logger

def train_one_epoch(model, dataloader, criterion, optimizer, device, epoch, logger):
    model.train()
    total_loss = 0
    
    with tqdm(dataloader, desc=f'Epoch {epoch} [Train]') as pbar:
        for batch_idx, (images, masks) in enumerate(pbar):
            images = images.to(device)
            masks = masks.to(device)
            
            # 前向传播
            outputs = model(images)
            loss = criterion(outputs, masks)
            
            # 反向传播
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
            # 更新进度条
            pbar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    avg_loss = total_loss / len(dataloader)
    logger.info(f'Epoch {epoch} - Average Loss: {avg_loss:.4f}')
    return avg_loss

def validate(model, dataloader, criterion, device, epoch, logger):
    model.eval()
    total_loss = 0
    all_preds = []
    all_masks = []
    
    with torch.no_grad():
        with tqdm(dataloader, desc=f'Epoch {epoch} [Val]') as pbar:
            for images, masks in pbar:
                images = images.to(device)
                masks = masks.to(device)
                
                # 前向传播
                outputs = model(images)
                loss = criterion(outputs, masks)
                
                total_loss += loss.item()
                
                # 收集预测结果
                preds = torch.sigmoid(outputs) > 0.5
                all_preds.extend(preds.cpu().numpy())
                all_masks.extend(masks.cpu().numpy())
                
                # 更新进度条
                pbar.set_postfix({'loss': f'{loss.item():.4f}'})
    
    # 计算指标
    metrics = calculate_metrics(np.array(all_preds), np.array(all_masks))
    avg_loss = total_loss / len(dataloader)
    
    logger.info(f'Epoch {epoch} - Validation Loss: {avg_loss:.4f}')
    logger.info(f'Epoch {epoch} - Metrics: {metrics}')
    
    return avg_loss, metrics

def main():
    # 设置随机种子
    torch.manual_seed(42)
    np.random.seed(42)
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 创建保存目录
    save_dir = os.path.join('checkpoints', datetime.now().strftime('%Y%m%d_%H%M%S'))
    os.makedirs(save_dir, exist_ok=True)
    
    # 设置日志
    logger = setup_logger(save_dir)
    logger.info('Starting training...')
    
    # 创建模型
    model = DCSMUnet(
        in_channels=3,
        out_channels=1,
        embed_dim=96
    ).to(device)
    
    # 设置损失函数
    criterion = nn.BCEWithLogitsLoss()
    
    # 设置优化器
    optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    
    # 设置学习率调度器
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, verbose=True
    )
    
    # 设置数据加载器
    train_dataset = YourDataset(mode='train')  # 需要根据实际数据集修改
    val_dataset = YourDataset(mode='val')      # 需要根据实际数据集修改
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=8,
        shuffle=True,
        num_workers=4,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=8,
        shuffle=False,
        num_workers=4,
        pin_memory=True
    )
    
    # 设置TensorBoard
    writer = SummaryWriter(log_dir=os.path.join(save_dir, 'logs'))
    
    # 训练循环
    num_epochs = 100
    best_val_loss = float('inf')
    
    for epoch in range(num_epochs):
        # 训练一个epoch
        train_loss = train_one_epoch(
            model, train_loader, criterion, optimizer, device, epoch, logger
        )
        
        # 验证
        val_loss, metrics = validate(
            model, val_loader, criterion, device, epoch, logger
        )
        
        # 更新学习率
        scheduler.step(val_loss)
        
        # 记录到TensorBoard
        writer.add_scalar('Loss/train', train_loss, epoch)
        writer.add_scalar('Loss/val', val_loss, epoch)
        for metric_name, metric_value in metrics.items():
            writer.add_scalar(f'Metrics/{metric_name}', metric_value, epoch)
        
        # 保存最佳模型
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'metrics': metrics
            }, os.path.join(save_dir, 'best_model.pth'))
            logger.info(f'Saved best model at epoch {epoch}')
        
        # 定期保存检查点
        if (epoch + 1) % 10 == 0:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'metrics': metrics
            }, os.path.join(save_dir, f'checkpoint_epoch_{epoch+1}.pth'))
    
    writer.close()
    logger.info('Training completed!')

if __name__ == '__main__':
    main()
