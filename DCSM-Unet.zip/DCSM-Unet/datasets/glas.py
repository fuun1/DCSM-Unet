import os
import numpy as np
import torch
from torch.utils.data import Dataset
from PIL import Image
from typing import Tuple, Optional, Dict, List
from .transforms import GlaSTransforms

class GlaSDataset(Dataset):
    """GlaS数据集加载器
    
    GlaS (Gland Segmentation) 数据集是一个用于腺体分割的医学图像数据集。
    包含85张训练图像和80张测试图像。
    """
    
    def __init__(
        self,
        root_dir: str,
        split: str = 'train',
        transform: Optional[GlaSTransforms] = None,
        image_size: Tuple[int, int] = (224, 224)
    ):
        """
        参数:
            root_dir (str): 数据集根目录
            split (str): 'train' 或 'test'
            transform (GlaSTransforms, optional): 数据转换
            image_size (Tuple[int, int]): 图像大小
        """
        self.root_dir = root_dir
        self.split = split
        self.image_size = image_size
        
        # 设置转换
        if transform is None:
            self.transform = GlaSTransforms(image_size=image_size)
        else:
            self.transform = transform
            
        # 获取图像和掩码路径
        self.image_dir = os.path.join(root_dir, split, 'images')
        self.mask_dir = os.path.join(root_dir, split, 'masks')
        
        # 获取所有图像文件名
        self.image_files = sorted([f for f in os.listdir(self.image_dir) if f.endswith('.png')])
        
    def __len__(self) -> int:
        return len(self.image_files)
    
    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        # 获取图像和掩码路径
        img_name = self.image_files[idx]
        img_path = os.path.join(self.image_dir, img_name)
        mask_path = os.path.join(self.mask_dir, img_name.replace('.png', '_mask.png'))
        
        # 读取图像和掩码
        image = np.array(Image.open(img_path).convert('RGB'))
        mask = np.array(Image.open(mask_path).convert('L'))
        
        # 应用转换
        if self.split == 'train':
            transformed = self.transform.get_train_transform()(image=image, mask=mask)
        else:
            transformed = self.transform.get_val_transform()(image=image, mask=mask)
            
        return {
            'image': transformed['image'],
            'mask': transformed['mask'].unsqueeze(0),  # 添加通道维度
            'image_path': img_path,
            'mask_path': mask_path
        }
    
    @staticmethod
    def get_class_weights() -> torch.Tensor:
        """获取类别权重（用于处理类别不平衡）"""
        return torch.tensor([0.5, 0.5])  # 二分类问题 