import torch
import torch.nn as nn
import torch.nn.functional as F

class DiceLoss(nn.Module):
    """Dice Loss 实现
    
    Args:
        smooth: 平滑项，防止除零错误
        eps: 数值稳定性参数
    """
    def __init__(self, smooth=1.0, eps=1e-7):
        super().__init__()
        self.smooth = smooth
        self.eps = eps
        
    def forward(self, pred, target):
        pred = torch.sigmoid(pred)
        pred_flat = pred.view(-1)
        target_flat = target.view(-1)
        
        intersection = (pred_flat * target_flat).sum()
        dice = (2. * intersection + self.smooth) / (pred_flat.sum() + target_flat.sum() + self.smooth + self.eps)
        
        return 1 - dice

class BCEWithLogitsLoss(nn.Module):
    """带 Logits 的二元交叉熵损失
    
    这个损失函数结合了 Sigmoid 激活和 BCE 损失，数值上更稳定。
    """
    def __init__(self):
        super().__init__()
        self.bce = nn.BCEWithLogitsLoss()
        
    def forward(self, pred, target):
        return self.bce(pred, target)

class CombinedLoss(nn.Module):
    """组合损失：BCE + Dice Loss
    
    Args:
        bce_weight: BCE 损失的权重
        dice_weight: Dice 损失的权重
        smooth: Dice Loss 的平滑项
        eps: Dice Loss 的数值稳定性参数
    """
    def __init__(self, bce_weight=0.5, dice_weight=0.5, smooth=1.0, eps=1e-7):
        super().__init__()
        self.bce_weight = bce_weight
        self.dice_weight = dice_weight
        self.bce = BCEWithLogitsLoss()
        self.dice = DiceLoss(smooth=smooth, eps=eps)
        
    def forward(self, pred, target):
        bce_loss = self.bce(pred, target)
        dice_loss = self.dice(pred, target)
        
        return self.bce_weight * bce_loss + self.dice_weight * dice_loss

def get_loss(loss_type='combined', **kwargs):
    """获取损失函数
    
    Args:
        loss_type: 损失函数类型，可选 'bce', 'dice', 'combined'
        **kwargs: 损失函数的其他参数
    
    Returns:
        loss_fn: 损失函数实例
    """
    if loss_type == 'bce':
        return BCEWithLogitsLoss()
    elif loss_type == 'dice':
        return DiceLoss(**kwargs)
    elif loss_type == 'combined':
        return CombinedLoss(**kwargs)
    else:
        raise ValueError(f"Unknown loss type: {loss_type}")

def dice_loss(pred, target):
    """Dice Loss 实现"""
    smooth = 1e-5
    pred = torch.sigmoid(pred)
    pred_flat = pred.view(-1)
    target_flat = target.view(-1)
    intersection = (pred_flat * target_flat).sum()
    return 1 - (2. * intersection + smooth) / (pred_flat.sum() + target_flat.sum() + smooth)

def combined_loss(pred, target):
    """组合损失：BCE + Dice Loss"""
    bce = F.binary_cross_entropy_with_logits(pred, target)
    dice = dice_loss(pred, target)
    return bce + dice

class FocalLoss(nn.Module):
    """Focal Loss 实现"""
    def __init__(self, alpha=0.25, gamma=2):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        
    def forward(self, pred, target):
        bce = F.binary_cross_entropy_with_logits(pred, target, reduction='none')
        pred_prob = torch.sigmoid(pred)
        p_t = target * pred_prob + (1 - target) * (1 - pred_prob)
        alpha_factor = target * self.alpha + (1 - target) * (1 - self.alpha)
        modulating_factor = (1.0 - p_t) ** self.gamma
        loss = alpha_factor * modulating_factor * bce
        return loss.mean() 