import os
import torch
import torchvision.models as models
from torch.hub import download_url_to_file
from typing import Optional
import logging

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 预训练模型URL
PRETRAINED_URLS = {
    'resnet34': 'https://download.pytorch.org/models/resnet34-333f7ec4.pth'
}

# 预训练模型保存路径
PRETRAINED_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'pretrained')
RESNET34_DIR = os.path.join(PRETRAINED_DIR, 'resnet34')
RESNET34_PATH = os.path.join(RESNET34_DIR, 'resnet34.pth')

def download_pretrained_weights(model_name: str = 'resnet34', force_download: bool = False) -> Optional[str]:
    """下载预训练权重
    
    参数:
        model_name (str): 模型名称，目前支持 'resnet34'
        force_download (bool): 是否强制重新下载
        
    返回:
        str: 预训练权重文件路径，如果下载失败则返回 None
    """
    if model_name not in PRETRAINED_URLS:
        logger.error(f"不支持的模型名称: {model_name}")
        return None
        
    # 创建保存目录
    os.makedirs(RESNET34_DIR, exist_ok=True)
    
    # 检查文件是否已存在
    if os.path.exists(RESNET34_PATH) and not force_download:
        logger.info(f"预训练权重已存在: {RESNET34_PATH}")
        return RESNET34_PATH
        
    try:
        # 下载预训练权重
        logger.info(f"正在下载 {model_name} 预训练权重...")
        download_url_to_file(
            PRETRAINED_URLS[model_name],
            RESNET34_PATH,
            progress=True
        )
        logger.info(f"预训练权重下载完成: {RESNET34_PATH}")
        return RESNET34_PATH
    except Exception as e:
        logger.error(f"下载预训练权重失败: {str(e)}")
        return None

def load_pretrained_weights(model: torch.nn.Module, model_name: str = 'resnet34') -> torch.nn.Module:
    """加载预训练权重到模型
    
    参数:
        model (torch.nn.Module): 要加载权重的模型
        model_name (str): 模型名称
        
    返回:
        torch.nn.Module: 加载了预训练权重的模型
    """
    # 下载预训练权重
    weights_path = download_pretrained_weights(model_name)
    if weights_path is None:
        logger.warning("无法加载预训练权重，将使用随机初始化的权重")
        return model
        
    try:
        # 加载预训练权重
        state_dict = torch.load(weights_path, map_location='cpu')
        
        # 处理权重键名不匹配的情况
        if isinstance(model, models.ResNet):
            # 移除 'module.' 前缀（如果有）
            state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
            
            # 只加载编码器部分的权重
            encoder_state_dict = {k: v for k, v in state_dict.items() if k.startswith('conv1') or k.startswith('layer')}
            model.load_state_dict(encoder_state_dict, strict=False)
            
        logger.info(f"成功加载预训练权重: {weights_path}")
        return model
    except Exception as e:
        logger.error(f"加载预训练权重失败: {str(e)}")
        return model

if __name__ == '__main__':
    # 测试下载和加载预训练权重
    model = models.resnet34(pretrained=False)
    model = load_pretrained_weights(model) 