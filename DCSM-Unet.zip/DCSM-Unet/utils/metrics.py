import torch
import numpy as np
from scipy.ndimage import distance_transform_edt
from scipy.spatial.distance import directed_hausdorff

def calculate_hd95(pred, target):
    """计算 Hausdorff Distance 95th percentile (HD95)
    
    Args:
        pred: 预测结果，范围 [0,1]，形状为 (H, W) 或 (B, H, W)
        target: 真实标签，范围 [0,1]，形状为 (H, W) 或 (B, H, W)
    
    Returns:
        hd95: HD95 值
    """
    # 确保输入是 numpy 数组
    if isinstance(pred, torch.Tensor):
        pred = pred.detach().cpu().numpy()
    if isinstance(target, torch.Tensor):
        target = target.detach().cpu().numpy()
    
    # 处理批处理数据
    if len(pred.shape) == 3:
        hd95_list = []
        for p, t in zip(pred, target):
            hd95_list.append(calculate_hd95(p, t))
        return np.mean(hd95_list)
    
    # 二值化
    pred = (pred > 0.5).astype(np.uint8)
    target = (target > 0.5).astype(np.uint8)
    
    # 计算距离变换
    pred_dist = distance_transform_edt(pred)
    target_dist = distance_transform_edt(target)
    
    # 计算 Hausdorff 距离
    hd1 = directed_hausdorff(pred_dist, target_dist)[0]
    hd2 = directed_hausdorff(target_dist, pred_dist)[0]
    hd = max(hd1, hd2)
    
    # 计算 95th percentile
    hd95 = np.percentile([hd1, hd2], 95)
    
    return hd95

def calculate_precision(pred, target):
    """计算精确率 (Precision)
    
    Args:
        pred: 预测结果，范围 [0,1]
        target: 真实标签，范围 [0,1]
    
    Returns:
        precision: 精确率值
    """
    pred = (pred > 0.5).float()
    true_positives = (pred * target).sum()
    predicted_positives = pred.sum()
    return (true_positives + 1e-6) / (predicted_positives + 1e-6)

def calculate_iou(pred, target):
    """计算 IoU (Intersection over Union)
    
    Args:
        pred: 预测结果，范围 [0,1]
        target: 真实标签，范围 [0,1]
    
    Returns:
        iou: IoU 值
    """
    pred = (pred > 0.5).float()
    intersection = (pred * target).sum()
    union = pred.sum() + target.sum() - intersection
    return (intersection + 1e-6) / (union + 1e-6)

def calculate_dice(pred, target):
    """计算 Dice 系数
    
    Args:
        pred: 预测结果，范围 [0,1]
        target: 真实标签，范围 [0,1]
    
    Returns:
        dice: Dice 系数值
    """
    pred = (pred > 0.5).float()
    intersection = (pred * target).sum()
    return (2. * intersection + 1e-6) / (pred.sum() + target.sum() + 1e-6)

def calculate_recall(pred, target):
    """计算召回率 (Recall)
    
    Args:
        pred: 预测结果，范围 [0,1]
        target: 真实标签，范围 [0,1]
    
    Returns:
        recall: 召回率值
    """
    pred = (pred > 0.5).float()
    true_positives = (pred * target).sum()
    actual_positives = target.sum()
    return (true_positives + 1e-6) / (actual_positives + 1e-6)

def calculate_f1_score(pred, target):
    """计算 F1 分数
    
    Args:
        pred: 预测结果，范围 [0,1]
        target: 真实标签，范围 [0,1]
    
    Returns:
        f1: F1 分数值
    """
    precision = calculate_precision(pred, target)
    recall = calculate_recall(pred, target)
    return (2 * precision * recall + 1e-6) / (precision + recall + 1e-6)

def calculate_metrics(preds, masks):
    """
    计算分割评估指标
    
    参数:
        preds: 预测结果，形状为 (N, H, W)
        masks: 真实标签，形状为 (N, H, W)
    
    返回:
        包含各项指标的字典
    """
    metrics = {}
    
    # 计算IoU
    intersection = np.logical_and(preds, masks).sum()
    union = np.logical_or(preds, masks).sum()
    iou = intersection / (union + 1e-8)
    metrics['iou'] = iou
    
    # 计算Dice系数
    dice = (2 * intersection) / (preds.sum() + masks.sum() + 1e-8)
    metrics['dice'] = dice
    
    # 计算精确率和召回率
    tp = intersection
    fp = preds.sum() - tp
    fn = masks.sum() - tp
    
    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    
    metrics['precision'] = precision
    metrics['recall'] = recall
    
    # 计算F1分数
    f1 = 2 * (precision * recall) / (precision + recall + 1e-8)
    metrics['f1'] = f1
    
    # 计算Hausdorff距离
    hd95 = 0
    for pred, mask in zip(preds, masks):
        if pred.sum() > 0 and mask.sum() > 0:
            pred_coords = np.argwhere(pred)
            mask_coords = np.argwhere(mask)
            hd = max(
                directed_hausdorff(pred_coords, mask_coords)[0],
                directed_hausdorff(mask_coords, pred_coords)[0]
            )
            hd95 += hd
    hd95 /= len(preds)
    metrics['hd95'] = hd95
    
    return metrics 