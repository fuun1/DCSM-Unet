import torch
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

def visualize_prediction(image, pred, target=None, save_path=None):
    """可视化预测结果"""
    plt.figure(figsize=(15, 5))
    
    # 显示原始图像
    plt.subplot(131)
    plt.imshow(image.squeeze().cpu().numpy(), cmap='gray')
    plt.title('Input Image')
    plt.axis('off')
    
    # 显示预测结果
    plt.subplot(132)
    plt.imshow(pred.squeeze().cpu().numpy(), cmap='gray')
    plt.title('Prediction')
    plt.axis('off')
    
    # 如果有目标图像，显示目标
    if target is not None:
        plt.subplot(133)
        plt.imshow(target.squeeze().cpu().numpy(), cmap='gray')
        plt.title('Ground Truth')
        plt.axis('off')
    
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()

def save_prediction(pred, save_path):
    """保存预测结果为图像"""
    pred = (pred.squeeze().cpu().numpy() * 255).astype(np.uint8)
    Image.fromarray(pred).save(save_path) 