import os
import logging
import sys
from datetime import datetime
from typing import Optional
import torch
from torch.utils.tensorboard import SummaryWriter

class Logger:
    """日志管理类"""
    
    def __init__(
        self,
        log_dir: str = 'logs',
        exp_name: Optional[str] = None,
        log_level: int = logging.INFO,
        use_tensorboard: bool = True
    ):
        """
        参数:
            log_dir (str): 日志保存目录
            exp_name (str, optional): 实验名称，如果为None则使用时间戳
            log_level (int): 日志级别
            use_tensorboard (bool): 是否使用TensorBoard
        """
        # 创建日志目录
        self.log_dir = os.path.join(log_dir, exp_name or datetime.now().strftime('%Y%m%d_%H%M%S'))
        os.makedirs(self.log_dir, exist_ok=True)
        
        # 设置日志格式
        self.log_format = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # 创建文件处理器
        self.file_handler = logging.FileHandler(
            os.path.join(self.log_dir, 'train.log'),
            encoding='utf-8'
        )
        self.file_handler.setFormatter(self.log_format)
        
        # 创建控制台处理器
        self.console_handler = logging.StreamHandler(sys.stdout)
        self.console_handler.setFormatter(self.log_format)
        
        # 配置根日志记录器
        self.logger = logging.getLogger()
        self.logger.setLevel(log_level)
        self.logger.addHandler(self.file_handler)
        self.logger.addHandler(self.console_handler)
        
        # 创建TensorBoard写入器
        self.writer = None
        if use_tensorboard:
            self.writer = SummaryWriter(log_dir=self.log_dir)
            
        # 记录系统信息
        self.log_system_info()
        
    def log_system_info(self):
        """记录系统信息"""
        self.info("=" * 50)
        self.info("系统信息:")
        self.info(f"PyTorch版本: {torch.__version__}")
        self.info(f"CUDA是否可用: {torch.cuda.is_available()}")
        if torch.cuda.is_available():
            self.info(f"CUDA版本: {torch.version.cuda}")
            self.info(f"GPU数量: {torch.cuda.device_count()}")
            self.info(f"当前GPU: {torch.cuda.get_device_name(0)}")
        self.info("=" * 50)
        
    def info(self, msg: str):
        """记录信息级别的日志"""
        self.logger.info(msg)
        
    def warning(self, msg: str):
        """记录警告级别的日志"""
        self.logger.warning(msg)
        
    def error(self, msg: str):
        """记录错误级别的日志"""
        self.logger.error(msg)
        
    def debug(self, msg: str):
        """记录调试级别的日志"""
        self.logger.debug(msg)
        
    def log_metrics(self, metrics: dict, step: int, prefix: str = ''):
        """记录评估指标
        
        参数:
            metrics (dict): 指标字典
            step (int): 当前步数
            prefix (str): 指标名称前缀
        """
        # 记录到日志文件
        metrics_str = ', '.join([f"{k}: {v:.4f}" for k, v in metrics.items()])
        self.info(f"Step {step} - {prefix} {metrics_str}")
        
        # 记录到TensorBoard
        if self.writer is not None:
            for k, v in metrics.items():
                self.writer.add_scalar(f"{prefix}/{k}", v, step)
                
    def log_model_graph(self, model: torch.nn.Module, input_shape: tuple):
        """记录模型结构图
        
        参数:
            model (torch.nn.Module): 模型
            input_shape (tuple): 输入张量形状
        """
        if self.writer is not None:
            dummy_input = torch.randn(input_shape)
            self.writer.add_graph(model, dummy_input)
            
    def log_images(self, tag: str, images: torch.Tensor, step: int):
        """记录图像
        
        参数:
            tag (str): 图像标签
            images (torch.Tensor): 图像张量 [B, C, H, W]
            step (int): 当前步数
        """
        if self.writer is not None:
            self.writer.add_images(tag, images, step)
            
    def close(self):
        """关闭日志记录器"""
        if self.writer is not None:
            self.writer.close()
            
        # 移除处理器
        self.logger.removeHandler(self.file_handler)
        self.logger.removeHandler(self.console_handler)
        
        # 关闭文件处理器
        self.file_handler.close()

def setup_logger(save_dir):
    """
    设置日志记录器
    
    参数:
        save_dir: 日志保存目录
    
    返回:
        logger: 配置好的日志记录器
    """
    # 创建日志目录
    log_dir = os.path.join(save_dir, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # 创建日志记录器
    logger = logging.getLogger('DCSM-Unet')
    logger.setLevel(logging.INFO)
    
    # 创建文件处理器
    log_file = os.path.join(log_dir, f'train_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.INFO)
    
    # 创建控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # 设置日志格式
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    # 添加处理器
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger 