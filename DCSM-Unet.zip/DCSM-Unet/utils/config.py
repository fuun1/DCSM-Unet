from dataclasses import dataclass
from typing import Optional, List, Tuple

@dataclass
class Config:
    # 数据相关
    data_dir: str = "data"
    train_batch_size: int = 16  # RTX 3080 Ti 可以支持更大的批次
    val_batch_size: int = 16
    num_workers: int = 4
    image_size: Tuple[int, int] = (224, 224)  # 标准化图像尺寸
    
    # 模型相关
    in_channels: int = 3
    out_channels: int = 1
    base_channels: int = 64
    pretrained: bool = True  # 使用 ImageNet 预训练权重
    
    # 训练相关
    epochs: int = 100
    learning_rate: float = 1e-3  # 初始学习率
    weight_decay: float = 1e-4  # AdamW 权重衰减
    device: str = "cuda"
    
    # 优化器相关
    optimizer: str = "adamw"  # 使用 AdamW
    beta1: float = 0.9
    beta2: float = 0.999
    
    # 学习率调度器
    scheduler: str = "cosine"  # 使用余弦退火
    warmup_epochs: int = 5
    min_lr: float = 1e-6
    
    # 数据增强
    augmentations: List[str] = [
        "horizontal_flip",
        "vertical_flip",
        "random_flip"
    ]
    
    # 损失函数
    loss_type: str = "combined"
    
    # 保存和日志
    save_dir: str = "checkpoints"
    log_dir: str = "logs"
    save_freq: int = 5
    
    # 其他
    seed: int = 42
    mixed_precision: bool = True  # 使用混合精度训练
    gradient_clip: float = 1.0 