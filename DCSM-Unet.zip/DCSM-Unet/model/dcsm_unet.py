import torch
import torch.nn as nn
from .blocks.deeM import DeeM
from .blocks.vss import VSS
from .blocks.gfm import GFM
from .blocks.patch_embed import PatchEmbed
from .blocks.patch_expand import PatchExpand

class DCSMUnet(nn.Module):
    def __init__(self, in_channels=3, out_channels=1, embed_dim=96):
        super().__init__()
        
        # 编码器 - 卷积路径 (DCNet)
        self.conv_encoder = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(in_channels, 64, kernel_size=7, stride=2, padding=3),
                nn.BatchNorm2d(64),
                nn.ReLU(inplace=True)
            ),
            self._make_layer(64, 128, 2),
            self._make_layer(128, 256, 2),
            self._make_layer(256, 512, 2)
        ])
        
        # 编码器 - Mamba路径
        self.patch_embed = PatchEmbed(
            patch_size=4,
            in_channels=in_channels,
            embed_dim=embed_dim
        )
        
        self.mamba_encoder = nn.ModuleList([
            VSS(embed_dim),
            VSS(embed_dim * 2),
            VSS(embed_dim * 4),
            VSS(embed_dim * 8)
        ])
        
        # 特征融合模块
        self.fusion_modules = nn.ModuleList([
            GFM(64, embed_dim),
            GFM(128, embed_dim * 2),
            GFM(256, embed_dim * 4),
            GFM(512, embed_dim * 8)
        ])
        
        # 解码器
        self.decoder = nn.ModuleList([
            nn.Sequential(
                PatchExpand(embed_dim * 8, embed_dim * 4),
                VSS(embed_dim * 4)
            ),
            nn.Sequential(
                PatchExpand(embed_dim * 4, embed_dim * 2),
                VSS(embed_dim * 2)
            ),
            nn.Sequential(
                PatchExpand(embed_dim * 2, embed_dim),
                VSS(embed_dim)
            ),
            nn.Sequential(
                PatchExpand(embed_dim, embed_dim // 2),
                VSS(embed_dim // 2)
            )
        ])
        
        # 输出层
        self.final_conv = nn.Conv2d(embed_dim // 2, out_channels, kernel_size=1)
        
    def _make_layer(self, in_channels, out_channels, num_blocks):
        layers = []
        layers.append(nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=2, padding=1))
        layers.append(nn.BatchNorm2d(out_channels))
        layers.append(nn.ReLU(inplace=True))
        for _ in range(num_blocks):
            layers.append(nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1))
            layers.append(nn.BatchNorm2d(out_channels))
            layers.append(nn.ReLU(inplace=True))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        # 编码器 - 卷积路径
        conv_features = []
        for conv_layer in self.conv_encoder:
            x_conv = conv_layer(x)
            conv_features.append(x_conv)
        
        # 编码器 - Mamba路径
        x_mamba = self.patch_embed(x)
        mamba_features = []
        for mamba_layer in self.mamba_encoder:
            x_mamba = mamba_layer(x_mamba)
            mamba_features.append(x_mamba)
        
        # 特征融合
        fused_features = []
        for conv_feat, mamba_feat, fusion_module in zip(conv_features, mamba_features, self.fusion_modules):
            fused_feat = fusion_module(conv_feat, mamba_feat)
            fused_features.append(fused_feat)
        
        # 解码器
        x = fused_features[-1]
        for i, decoder_layer in enumerate(self.decoder):
            x = decoder_layer(x)
            if i < len(fused_features) - 1:
                x = x + fused_features[-(i+2)]
        
        # 输出层
        x = self.final_conv(x)
        return x 