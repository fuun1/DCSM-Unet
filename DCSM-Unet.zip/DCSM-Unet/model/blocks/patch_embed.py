import torch
import torch.nn as nn

class PatchEmbed(nn.Module):
    def __init__(self, patch_size=4, in_channels=3, embed_dim=96):
        super().__init__()
        
        self.patch_size = patch_size
        self.embed_dim = embed_dim
        
        # 投影层
        self.proj = nn.Conv2d(
            in_channels,
            embed_dim,
            kernel_size=patch_size,
            stride=patch_size
        )
        
        # 层归一化
        self.norm = nn.LayerNorm(embed_dim)
        
    def forward(self, x):
        # 投影
        x = self.proj(x)  # B, C, H, W
        
        # 重塑为序列形式
        B, C, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)  # B, HW, C
        
        # 归一化
        x = self.norm(x)
        
        # 重塑回空间形式
        x = x.transpose(1, 2).reshape(B, C, H, W)
        
        return x 