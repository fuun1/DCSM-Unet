import torch
import torch.nn as nn
import torch.nn.functional as F

class VSS(nn.Module):
    """视觉状态空间块"""
    def __init__(self, dim, depth=2):
        super().__init__()
        
        self.dim = dim
        self.depth = depth
        
        # 状态空间模型参数
        self.A = nn.Parameter(torch.randn(dim, dim))
        self.B = nn.Parameter(torch.randn(dim, dim))
        self.C = nn.Parameter(torch.randn(dim, dim))
        
        # 层归一化
        self.norm = nn.LayerNorm(dim)
        
        # 前馈网络
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Linear(dim * 4, dim)
        )
        
    def forward(self, x):
        B, C, H, W = x.shape
        
        # 重塑为序列形式
        x = x.flatten(2).transpose(1, 2)  # B, HW, C
        
        # 状态空间建模
        for _ in range(self.depth):
            # 层归一化
            x_norm = self.norm(x)
            
            # 状态空间计算
            state = torch.zeros(B, H*W, self.dim, device=x.device)
            for t in range(H*W):
                if t == 0:
                    state[:, t] = torch.matmul(x_norm[:, t], self.B)
                else:
                    state[:, t] = torch.matmul(state[:, t-1], self.A) + torch.matmul(x_norm[:, t], self.B)
            
            # 输出计算
            output = torch.matmul(state, self.C)
            
            # 残差连接
            x = x + output
            
            # 前馈网络
            x = x + self.ffn(self.norm(x))
        
        # 重塑回空间形式
        x = x.transpose(1, 2).reshape(B, C, H, W)
        
        return x 