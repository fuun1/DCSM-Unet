import torch
import torch.nn as nn

class PatchExpand(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        
        self.in_channels = in_channels
        self.out_channels = out_channels
        
        # 上采样卷积
        self.expand = nn.ConvTranspose2d(
            in_channels,
            out_channels,
            kernel_size=2,
            stride=2
        )
        
        # 层归一化
        self.norm = nn.LayerNorm(out_channels)
        
    def forward(self, x):
        # 上采样
        x = self.expand(x)  # B, C, H*2, W*2
        
        # 重塑为序列形式
        B, C, H, W = x.shape
        x = x.flatten(2).transpose(1, 2)  # B, HW, C
        
        # 归一化
        x = self.norm(x)
        
        # 重塑回空间形式
        x = x.transpose(1, 2).reshape(B, C, H, W)
        
        return x 