# DCSM-Unet: 基于深度卷积和状态空间模型的医学图像分割网络

## 项目简介

DCSM-Unet 是一个创新的医学图像分割模型，它结合了深度卷积神经网络和状态空间模型（Mamba）的优势。该模型具有以下特点：

- 使用 ResNet34 作为编码器骨干网络
- 引入 Mamba 路径进行特征提取
- 采用 Patch Embedding 进行特征表示
- 通过 GFM（Global Feature Module）模块实现特征融合
- 使用 U-Net 风格的解码器进行精确分割

## 主要特性

- 支持多种数据增强策略
- 使用混合精度训练提高效率
- 实现了多种评估指标（IoU、Dice、Precision、HD95等）
- 支持模型权重保存和加载
- 提供完整的训练和测试流程

## 环境要求

- Python 3.8+
- PyTorch 2.0+
- CUDA 11.0+ (推荐)
- 32GB GPU 显存

## 安装说明

1. 克隆仓库：
```bash
git clone https://github.com/yourusername/DCSM-Unet.git
cd DCSM-Unet
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

## 使用方法

### 训练模型

```bash
python train.py
```

### 测试模型

```bash
python test.py
```

## 项目结构

```
DCSM-Unet/
├── models/              # 模型定义
│   ├── blocks/         # 基础模块
│   └── dcsm_unet.py    # 主模型
├── utils/              # 工具函数
│   ├── config.py       # 配置文件
│   ├── metrics.py      # 评估指标
│   └── visualizer.py   # 可视化工具
├── train.py            # 训练脚本
├── test.py             # 测试脚本
├── requirements.txt    # 依赖列表
└── README.md          # 项目说明
```

## 配置说明

主要配置参数在 `utils/config.py` 中定义，包括：

- 训练参数（批次大小、学习率等）
- 模型参数（通道数、层数等）
- 数据增强策略
- 优化器设置

## 引用

如果您使用了本项目的代码，请引用：

```bibtex
@article{dcsm-unet,
  title={DCSM-Unet: A Deep Convolutional and State Space Model for Medical Image Segmentation},
  author={Your Name},
  journal={arXiv preprint},
  year={2024}
}
```

## 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。 